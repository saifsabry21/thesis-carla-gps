# Fixed GPS offset

All 14 checks passed.

Samples: {'clean': 50, 'attack': 50}. Maximum applied map-X offset: 5.0 m.

Maximum recorded sensor motion: 0.0 m.

Original sensor readings retained. Green = real position; red = reported position; arrow = position error, not trajectory. Guided review is recorded replay. No controller or VLA consumes the attacked output.
